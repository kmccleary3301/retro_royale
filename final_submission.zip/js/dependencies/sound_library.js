

sound_set = {
    hum : 'media/sounds/synth_1.mp3'
}